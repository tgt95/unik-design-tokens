import './styles/aui.pattern.forms';
import 'select2/select2.css';
import '@atlassian/aui/src/less/aui-select2.less';
import '@atlassian/aui/src/js/aui/select2.js';
export {};
