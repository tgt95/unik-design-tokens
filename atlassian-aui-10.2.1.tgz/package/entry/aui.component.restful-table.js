import './styles/aui.pattern.table';
import '@atlassian/aui/src/less/aui-experimental-restfultable.less';
export { default as RestfulTable } from '@atlassian/aui/src/js/aui/restful-table';
