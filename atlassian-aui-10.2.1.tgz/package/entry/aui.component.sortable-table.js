import './styles/aui.pattern.table';
import '@atlassian/aui/src/less/aui-experimental-tables-sortable.less';
import '@atlassian/aui/src/js/aui/tables-sortable.js';
export {};
