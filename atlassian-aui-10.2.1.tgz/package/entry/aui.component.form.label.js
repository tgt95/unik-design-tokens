import './styles/aui.pattern.forms';
export { default as LabelEl } from '@atlassian/aui/src/js/aui/label';
