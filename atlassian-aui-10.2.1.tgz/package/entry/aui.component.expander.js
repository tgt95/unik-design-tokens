import '@atlassian/aui/src/less/aui-experimental-expander.less';
import '@atlassian/aui/src/js/aui/expander.js';
export {};
