import '../../src/less/inline-dialog.less';
export { default as InlineDialog } from '../../src/js/aui/inline-dialog';
