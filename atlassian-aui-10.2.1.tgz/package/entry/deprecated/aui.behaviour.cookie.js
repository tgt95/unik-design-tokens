import * as cookie from '../../src/js/aui/cookie';
export default cookie;
