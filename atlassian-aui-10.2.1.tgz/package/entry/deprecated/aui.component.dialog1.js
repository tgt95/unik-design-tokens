import '../../src/less/dialog.less';
export * from '../../src/js/aui/dialog';
