export default 'jquery';
import '../../src/js/aui/spin';
