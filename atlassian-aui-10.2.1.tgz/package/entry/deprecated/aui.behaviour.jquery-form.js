// Using source so we can take the polyfills we want + sourcemaps + unminified builds
import 'jquery-form/src/jquery.form';
export default 'jquery';
