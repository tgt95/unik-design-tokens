import './styles/aui.page.reset';
import '@atlassian/aui/src/less/aui-spinner.less';
export { default as SpinnerEl } from '@atlassian/aui/src/js/aui/spinner';
