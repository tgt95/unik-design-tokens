export * from '@atlassian/aui/src/js/aui/escape-html';
