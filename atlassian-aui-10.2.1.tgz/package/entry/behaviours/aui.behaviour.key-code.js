export { default as keyCode } from '@atlassian/aui/src/js/aui/key-code';
