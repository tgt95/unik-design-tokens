// todo AUI-4814: undo the weird relationships between layer, layerManager, and LayerManager.global
export * from '@atlassian/aui/src/js/aui/layer-manager';
