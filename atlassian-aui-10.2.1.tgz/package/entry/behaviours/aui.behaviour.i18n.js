export { I18n as i18n } from '@atlassian/aui/src/js/aui/i18n';
