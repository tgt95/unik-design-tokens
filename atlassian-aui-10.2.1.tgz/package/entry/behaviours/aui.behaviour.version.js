export { default as version } from '@atlassian/aui/src/js/aui/version';
