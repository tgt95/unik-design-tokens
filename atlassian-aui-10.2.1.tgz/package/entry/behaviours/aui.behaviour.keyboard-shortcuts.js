export { default as whenIType } from '@atlassian/aui/src/js/aui/when-i-type';
