import '@atlassian/aui/src/js/aui/trigger';
export {};
