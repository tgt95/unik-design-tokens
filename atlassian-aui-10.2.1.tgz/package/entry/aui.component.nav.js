import './styles/aui.pattern.nav';
export { default as navigation, NavigationEl } from '@atlassian/aui/src/js/aui/navigation';
