import './styles/aui.pattern.messages'; // for header interop
import './styles/aui.pattern.banner';
export { default as banner } from '@atlassian/aui/src/js/aui/banner';
