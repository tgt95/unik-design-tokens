import '@atlassian/aui/src/js/aui/internal/deprecation';
