// iconfont v1: ADG 1 + 2
import '@atlassian/aui/src/less/iconfont-atlassian-icons.less';
// iconfont v2: ADG Server
import '@atlassian/aui/src/less/iconfont-adgs-icons.less';
