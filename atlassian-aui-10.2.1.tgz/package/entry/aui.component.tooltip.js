import './styles/aui.page.reset';
import './styles/aui.page.typography';
import '@atlassian/aui/src/less/aui-experimental-tooltip.less';
import '@atlassian/aui/src/js/aui/tooltip';
export {};
