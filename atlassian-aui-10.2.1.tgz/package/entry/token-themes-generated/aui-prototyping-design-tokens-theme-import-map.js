export default {
	'light': () => (() => {}),
	'light-future': () => (() => {}),
	'dark': () => (() => {}),
	'dark-future': () => (() => {}),
	'spacing': () => (() => {}),
	'shape': () => (() => {}),
	'typography': () => (() => {}),
	'motion': () => (() => {}),
};