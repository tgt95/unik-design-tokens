import './aui.component.message';
import '@atlassian/aui/src/less/flag.less';
export { default as flag } from '@atlassian/aui/src/js/aui/flag';
