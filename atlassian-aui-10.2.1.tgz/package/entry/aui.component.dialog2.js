import './aui.component.layer';
import './styles/aui.pattern.close-button';
import '@atlassian/aui/src/less/dialog2.less';
export { default as dialog2 } from '@atlassian/aui/src/js/aui/dialog2';
