import './styles/aui.pattern.tabs';
import './aui.component.dropdown2'; // to make responsive tabs work.
export * from '@atlassian/aui/src/js/aui/tabs';
