import './aui.page.reset';
import './aui.page.typography';
import './aui.page.iconography'; // todo: should only import what's needed from iconography
import './aui.page.links';
import './aui.pattern.basic';
import './aui.pattern.messages'; // because forms.less currently include interop styles for this pattern.
import '@atlassian/aui/src/js/aui/forms';
import '@atlassian/aui/src/less/forms.less';
