import './aui.pattern.icon';
import '@atlassian/aui/src/less/aui-close-button.less';
