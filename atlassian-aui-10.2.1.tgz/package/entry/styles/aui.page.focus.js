import './aui.page.reset';
import '@atlassian/aui/src/less/aui-focus.less';
