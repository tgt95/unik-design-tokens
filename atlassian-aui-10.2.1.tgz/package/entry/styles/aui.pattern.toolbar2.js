import './aui.page.reset';
import './aui.page.typography';
import './aui.pattern.button';
import '@atlassian/aui/src/less/aui-toolbar2.less';
