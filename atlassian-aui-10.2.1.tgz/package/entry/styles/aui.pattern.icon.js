import '@atlassian/aui/src/less/aui-icons.less'; // todo: split the icon pattern definition from the various (deprecated) glyphs.
