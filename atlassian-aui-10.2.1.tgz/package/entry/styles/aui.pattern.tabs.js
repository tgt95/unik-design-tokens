import './aui.page.reset';
import './aui.page.typography';
import '@atlassian/aui/src/less/tabs.less';
