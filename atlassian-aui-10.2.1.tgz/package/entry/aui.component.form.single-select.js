import './styles/aui.pattern.forms';
import '@atlassian/aui/src/less/single-select.less';
export { default as SelectEl } from '@atlassian/aui/src/js/aui/select';
