import { bindAll } from 'underscore';
import Backbone from 'backbone';
import globalize from './internal/globalize';

var QueryInput = Backbone.View.extend({
    initialize: function () {
        bindAll(this, 'changed', 'val');
        this._lastValue = this.val();
        this.$el.on('keyup focus', this.changed);
    },

    val: function () {
        return this.$el.val.apply(this.$el, arguments);
    },

    changed: function () {
        if (this._lastValue !== this.val()) {
            this.trigger('change', this.val());
            this._lastValue = this.val();
        }
    },
});

globalize('QueryInput', QueryInput);

export default QueryInput;
