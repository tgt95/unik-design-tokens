import layer from './layer';
export default layer.Manager.global;
