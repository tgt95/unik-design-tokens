export default {
    ENABLED_SUBMIT: 'enabledSubmit',
    ROW_VIEW: 'RestfulTable_Row_View',
};
