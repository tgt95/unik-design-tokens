import Backbone from 'backbone';
export default Backbone.View;
