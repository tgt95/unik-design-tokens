const INPUT_SUFFIX = '-input';

export { INPUT_SUFFIX };
