const parseJSON = (data) => {
    return JSON.parse(data || 'null');
};

export default parseJSON;
