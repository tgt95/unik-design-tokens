import skate from 'skatejs';

const auiSkate = skate.noConflict();

export default auiSkate;
