import FocusManager from './focus-manager';
export default FocusManager.global;
